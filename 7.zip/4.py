from flask import Flask, url_for, request, render_template

app = Flask(__name__)


@app.route('/choice/<planet_name>')
def results(planet_name):
    if planet_name.lower() == 'марс':
        return render_template('planets.html', planet_name=planet_name,
                               first_argument='Крутая планета!!!',
                               second_argument='Настолько крутая, что',
                               third_argument='даже нечего и говорить!!')
    return render_template('planets.html', planet_name=planet_name,
                           first_argument='На Марс не похоже, так что',
                           second_argument='лучше найти идею получше.',
                           third_argument='Попробуйте Марс.')


if __name__ == '__main__':
    app.run(port=9999, host='127.0.0.1', debug=True)
