from flask import Flask, url_for, request, render_template

app = Flask(__name__)


@app.route('/form', methods=['POST', 'GET'])
def form_sample():
    print({url_for('static', filename='static/css/style.css')})
    if request.method == 'GET':
        return render_template('form_sample.html')
    elif request.method == 'POST':
        return "Форма отправлена"


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)
